package Exceptions;

public class VariableException extends MyException{
    public VariableException(String message){ super("VariableException: " + message); }
}
